const daftarvip = (prefix) => { 
	return `
	
*PREÇO PARA SER PREMIUM :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo!

*SE QUiser REGISTrAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/556196333905 ou digite *${prefix}owner*_

 `
}
exports.daftarvip = daftarvip
